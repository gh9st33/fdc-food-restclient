# SampleFoodItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fdc_id** | **int** |  | 
**datatype** | **str** |  | [optional] 
**description** | **str** |  | 
**food_class** | **str** |  | [optional] 
**publication_date** | **str** |  | [optional] 
**food_attributes** | [**list[FoodCategory]**](FoodCategory.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


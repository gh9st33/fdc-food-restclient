# NutrientAcquisitionDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sample_unit_id** | **int** |  | [optional] 
**purchase_date** | **str** |  | [optional] 
**store_city** | **str** |  | [optional] 
**store_state** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# FoodComponent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**name** | **str** |  | [optional] 
**data_points** | **int** |  | [optional] 
**gram_weight** | **float** |  | [optional] 
**is_refuse** | **bool** |  | [optional] 
**min_year_acquired** | **int** |  | [optional] 
**percent_weight** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


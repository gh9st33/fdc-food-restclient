# AbridgedFoodNutrient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **int** |  | [optional] 
**name** | **str** |  | [optional] 
**amount** | **float** |  | [optional] 
**unit_name** | **str** |  | [optional] 
**derivation_code** | **str** |  | [optional] 
**derivation_description** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


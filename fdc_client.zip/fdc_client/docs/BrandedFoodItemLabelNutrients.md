# BrandedFoodItemLabelNutrients

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fat** | [**BrandedFoodItemLabelNutrientsFat**](BrandedFoodItemLabelNutrientsFat.md) |  | [optional] 
**saturated_fat** | [**BrandedFoodItemLabelNutrientsSaturatedFat**](BrandedFoodItemLabelNutrientsSaturatedFat.md) |  | [optional] 
**trans_fat** | [**BrandedFoodItemLabelNutrientsTransFat**](BrandedFoodItemLabelNutrientsTransFat.md) |  | [optional] 
**cholesterol** | [**BrandedFoodItemLabelNutrientsTransFat**](BrandedFoodItemLabelNutrientsTransFat.md) |  | [optional] 
**sodium** | [**BrandedFoodItemLabelNutrientsTransFat**](BrandedFoodItemLabelNutrientsTransFat.md) |  | [optional] 
**carbohydrates** | [**BrandedFoodItemLabelNutrientsCarbohydrates**](BrandedFoodItemLabelNutrientsCarbohydrates.md) |  | [optional] 
**fiber** | [**BrandedFoodItemLabelNutrientsFiber**](BrandedFoodItemLabelNutrientsFiber.md) |  | [optional] 
**sugars** | [**BrandedFoodItemLabelNutrientsSugars**](BrandedFoodItemLabelNutrientsSugars.md) |  | [optional] 
**protein** | [**BrandedFoodItemLabelNutrientsProtein**](BrandedFoodItemLabelNutrientsProtein.md) |  | [optional] 
**calcium** | [**BrandedFoodItemLabelNutrientsCalcium**](BrandedFoodItemLabelNutrientsCalcium.md) |  | [optional] 
**iron** | [**BrandedFoodItemLabelNutrientsIron**](BrandedFoodItemLabelNutrientsIron.md) |  | [optional] 
**potassium** | [**BrandedFoodItemLabelNutrientsPotassium**](BrandedFoodItemLabelNutrientsPotassium.md) |  | [optional] 
**calories** | [**BrandedFoodItemLabelNutrientsCalories**](BrandedFoodItemLabelNutrientsCalories.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

